﻿#if NETFX_CORE

using System;
using System.Collections.Generic;
using System.Text;

namespace NetworkCommsDotNet.Tools.XPlatformHelper
{
    public delegate void WaitCallback(object obj);    
}
#endif