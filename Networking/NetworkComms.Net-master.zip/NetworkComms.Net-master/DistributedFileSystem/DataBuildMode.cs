﻿// 
// Licensed to the Apache Software Foundation (ASF) under one
// or more contributor license agreements.  See the NOTICE file
// distributed with this work for additional information
// regarding copyright ownership.  The ASF licenses this file
// to you under the Apache License, Version 2.0 (the
// "License"); you may not use this file except in compliance
// with the License.  You may obtain a copy of the License at
// 
//   http://www.apache.org/licenses/LICENSE-2.0
// 
// Unless required by applicable law or agreed to in writing,
// software distributed under the License is distributed on an
// "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
// KIND, either express or implied.  See the License for the
// specific language governing permissions and limitations
// under the License.
// 

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DistributedFileSystem
{
    /// <summary>
    /// Describes where a distributed item should be stored during and after being assembled
    /// </summary>
    public enum DataBuildMode
    {
        /// <summary>
        /// Build the item to a single continuous memory stream. Requires sufficient memory during build.
        /// </summary>
        Memory_Single,

        /// <summary>
        /// Build the item to an array of memory streams. More high performance as reduces locking during build. Requires sufficient memory during build.
        /// </summary>
        Memory_Blocks,

        /// <summary>
        /// Build the item to the local application directory as a single file stream.
        /// </summary>
        Disk_Single,

        /// <summary>
        /// Build the item to the local application directory as an array of file streams. More high performance as reduces locking.
        /// </summary>
        Disk_Blocks,
    }
}
