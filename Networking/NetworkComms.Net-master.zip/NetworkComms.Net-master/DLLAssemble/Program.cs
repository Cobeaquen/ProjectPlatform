﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DLLAssemble
{
    class Program
    {
        static void Main(string[] args)
        {
            //Assemble all DLLs for release
            DLLAssemble.Assemble();
        }
    }
}
